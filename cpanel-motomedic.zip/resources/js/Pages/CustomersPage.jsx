import CustomersTable from "@/Components/tables/CustomersTable";
const CustomersPage = () => {
    return (
        <div>
            <CustomersTable />
        </div>
    );
};

export default CustomersPage;
